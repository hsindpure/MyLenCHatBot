# QlikSense AI Chatbot Extension

## Overview
This QlikSense extension provides an AI-powered chatbot that can analyze data from your QlikSense applications and provide intelligent insights through natural language conversations.

## Features
- **Smart Data Loading**: Automatically loads data from all objects on the current sheet
- **Hypercube Optimization**: Solves "hypercube too large" errors with intelligent pagination and data sampling
- **Multiple AI Personas**: Choose between Data Analyst, HR Leader, and Business Consultant roles
- **Voice Input**: Supports voice commands for hands-free interaction
- **Chat History**: Download conversation history for future reference
- **Real-time Analysis**: Get instant insights from your QlikSense data

## Installation

1. Download all files from this folder
2. Create a new folder in your QlikSense Extensions directory
3. Copy all files into the extension folder
4. Restart QlikSense or reload the extension
5. Add the extension to your QlikSense sheet

## Configuration

### Required Settings
- **OpenAI API Key**: Enter your OpenAI API key in the extension properties
- **Max Data Points**: Set the maximum number of data points to load per object (default: 1000)
- **Page Size**: Configure the pagination size for data fetching (default: 500)

### Role Prompts
Customize the AI behavior for each role:
- **Data Analyst**: Focuses on data patterns and statistical insights
- **HR Leader**: Specializes in employee and HR-related analysis
- **Business Consultant**: Provides strategic business recommendations

## Technical Solutions

### Hypercube Error Fix
The extension automatically handles large datasets by:
- **Pagination**: Fetches data in smaller chunks (configurable page size)
- **Data Sampling**: Intelligently samples data when datasets are too large
- **Batch Processing**: Processes multiple objects in batches to prevent system overload
- **Caching**: Caches loaded data to improve performance

### Smart Data Loading
- Automatically discovers all objects on the current sheet
- Loads data from charts, tables, and other visualizations
- Handles different object types gracefully
- Provides error handling for objects that can't be loaded

## Usage

1. **Open Chat**: Click the "AI CHATBOT" button to open the chat interface
2. **Select Role**: Choose your preferred AI persona (Data Analyst, HR Leader, Business Consultant)
3. **Ask Questions**: Type your questions about the data or use voice input
4. **Get Insights**: Receive AI-powered analysis and recommendations
5. **Download History**: Save your conversation for future reference

## File Structure

```
qliksense-chatbot-extension/
├── extension.js          # Main extension file
├── data-manager.js       # Handles data fetching and pagination
├── openai-client.js      # OpenAI API integration
├── chat-manager.js       # Chat UI management
├── template.html         # HTML template
├── style.css            # Styling
├── qext                 # Extension metadata
└── README.md           # This file
```

## API Requirements

- **OpenAI API Key**: You need a valid OpenAI API key to use the AI features
- **Internet Access**: The extension requires internet access to communicate with OpenAI

## Browser Compatibility

- Modern browsers with ES6+ support
- Chrome, Firefox, Safari, Edge (latest versions)
- WebKit Speech Recognition API for voice input (Chrome recommended)

## Troubleshooting

### Common Issues

1. **"Hypercube too large" error**
   - Reduce the "Max Data Points" setting
   - Decrease the "Page Size" setting
   - Check if objects have extremely large datasets

2. **API Key not working**
   - Verify your OpenAI API key is valid
   - Check if you have sufficient API credits
   - Ensure internet connectivity

3. **No data loading**
   - Verify objects exist on the current sheet
   - Check browser console for error messages
   - Ensure proper QlikSense permissions

### Performance Tips

- Set appropriate data limits based on your system capacity
- Use smaller page sizes for better responsiveness
- Clear browser cache if experiencing issues
- Monitor API usage to avoid rate limits

## Version History

- **v1.0.0**: Initial release with AI chatbot functionality, hypercube optimization, and multi-role support

## License

MIT License - Feel free to modify and distribute according to your needs.