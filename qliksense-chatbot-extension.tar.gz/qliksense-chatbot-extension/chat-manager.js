define(['jquery'], function($) {
    'use strict';

    /**
     * ChatManager for handling chat UI interactions
     */
    class ChatManager {
        constructor() {
            this.chatContainer = $('#GPTAnswear');
            this.typingIndicator = null;
        }

        /**
         * Add a message to the chat
         */
        addMessage(message, sender, role, containerClass = '') {
            const timestamp = new Date().toLocaleTimeString();
            
            if (sender === 'user') {
                this.addUserMessage(message, role, timestamp);
            } else {
                this.addAIMessage(message, role, containerClass, timestamp);
            }
            
            this.scrollToBottom();
        }

        /**
         * Add user message to chat
         */
        addUserMessage(message, role, timestamp) {
            const messageHtml = `
                <div class="question-chat">
                    <div class="user-div">
                        <span class="que_role_span">${role}</span>
                        <i class="fa fa-user-circle" aria-hidden="true"></i>
                    </div>
                    <div class="que-div">
                        ${this.escapeHtml(message)}
                    </div>
                    <div class="que-triangle"></div>
                </div>
            `;
            
            this.chatContainer.append(messageHtml);
        }

        /**
         * Add AI message to chat
         */
        addAIMessage(message, role, containerClass, timestamp) {
            const messageId = 'msg-' + Date.now();
            
            const messageHtml = `
                <div class="ans-chat-container ${containerClass}" id="${messageId}">
                    <div class="ans-triangle ${containerClass}"></div>
                    <div class="ans-chat">
                        <div class="user-div">
                            <i class="fa fa-robot" aria-hidden="true"></i>
                            <span class="role_span">${role}</span>
                        </div>
                        <div class="message-content">
                            ${message}
                        </div>
                        <div class="hear-responce">
                            <button class="copy-btn" onclick="chatManager.copyMessage('${messageId}')" title="Copy message">
                                <i class="fa fa-copy" aria-hidden="true"></i>
                            </button>
                            <button class="speak-btn" onclick="chatManager.speakMessage('${messageId}')" title="Read aloud">
                                <i class="fa fa-volume-up" aria-hidden="true"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            this.chatContainer.append(messageHtml);
            
            // Make this instance available globally for button callbacks
            window.chatManager = this;
        }

        /**
         * Show typing indicator
         */
        showTyping() {
            this.hideTyping(); // Remove any existing typing indicator
            
            const typingHtml = `
                <div class="typing-indicator" id="typing-indicator">
                    <div class="ans-chat-container">
                        <div class="ans-triangle"></div>
                        <div class="ans-chat">
                            <div class="user-div">
                                <i class="fa fa-robot" aria-hidden="true"></i>
                                <span class="role_span">AI is typing...</span>
                            </div>
                            <div class="is-typing">
                                <div class="jump1"></div>
                                <div class="jump2"></div>
                                <div class="jump3"></div>
                                <div class="jump4"></div>
                                <div class="jump5"></div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            this.chatContainer.append(typingHtml);
            this.scrollToBottom();
        }

        /**
         * Hide typing indicator
         */
        hideTyping() {
            $('#typing-indicator').remove();
        }

        /**
         * Copy message to clipboard
         */
        copyMessage(messageId) {
            const messageElement = document.getElementById(messageId);
            const messageContent = messageElement.querySelector('.message-content');
            
            if (messageContent) {
                const text = messageContent.innerText || messageContent.textContent;
                
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(text).then(() => {
                        this.showToast('Message copied to clipboard!');
                    }).catch(err => {
                        console.error('Failed to copy message:', err);
                        this.fallbackCopyText(text);
                    });
                } else {
                    this.fallbackCopyText(text);
                }
            }
        }

        /**
         * Fallback copy method for older browsers
         */
        fallbackCopyText(text) {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                this.showToast('Message copied to clipboard!');
            } catch (err) {
                console.error('Failed to copy message:', err);
                this.showToast('Failed to copy message');
            }
            
            document.body.removeChild(textArea);
        }

        /**
         * Speak message using Web Speech API
         */
        speakMessage(messageId) {
            const messageElement = document.getElementById(messageId);
            const messageContent = messageElement.querySelector('.message-content');
            
            if (messageContent && 'speechSynthesis' in window) {
                const text = messageContent.innerText || messageContent.textContent;
                
                // Stop any ongoing speech
                speechSynthesis.cancel();
                
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.rate = 0.8;
                utterance.pitch = 1;
                utterance.volume = 1;
                
                const speakBtn = messageElement.querySelector('.speak-btn');
                speakBtn.classList.add('speack-active');
                
                utterance.onend = () => {
                    speakBtn.classList.remove('speack-active');
                };
                
                utterance.onerror = () => {
                    speakBtn.classList.remove('speack-active');
                    this.showToast('Speech synthesis failed');
                };
                
                speechSynthesis.speak(utterance);
            } else {
                this.showToast('Speech synthesis not supported');
            }
        }

        /**
         * Show toast notification
         */
        showToast(message) {
            // Create toast element
            const toast = $(`
                <div class="toast-notification" style="
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: #333;
                    color: white;
                    padding: 10px 20px;
                    border-radius: 5px;
                    z-index: 10000;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                ">
                    ${message}
                </div>
            `);
            
            $('body').append(toast);
            
            // Animate in
            setTimeout(() => {
                toast.css('opacity', '1');
            }, 100);
            
            // Remove after 3 seconds
            setTimeout(() => {
                toast.css('opacity', '0');
                setTimeout(() => {
                    toast.remove();
                }, 300);
            }, 3000);
        }

        /**
         * Scroll chat to bottom
         */
        scrollToBottom() {
            this.chatContainer.scrollTop(this.chatContainer[0].scrollHeight);
        }

        /**
         * Clear chat
         */
        clearChat() {
            this.chatContainer.empty();
        }

        /**
         * Escape HTML to prevent XSS
         */
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }

    return ChatManager;
});
