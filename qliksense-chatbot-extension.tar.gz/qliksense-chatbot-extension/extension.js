define([
    "qlik",
    "text!./template.html",
    "css!./style.css",
    "jquery",
    "./data-manager",
    "./openai-client",
    "./chat-manager",
    "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js",
], function (qlik, template, css, $, DataManager, OpenAIClient, ChatManager) {
    'use strict';
    
    // Inject CSS
    $("<style>").html(css).appendTo("head");

    // Configuration objects
    const DropdownSelect = {
        ref: "prop.objectID",
        type: "string",
        label: "Select an Option",
        component: "dropdown",
        options: [
            {
                "value": "Act as a Data Analyst,",
                "label": "Act as a Analyst"
            },
            {
                "value": "Option2",
                "label": "Act as user"
            }
        ],
    };

    const ApiKey = {
        ref: "prop.apiKey",
        label: "Enter AI API Key",
        type: "string",
        expression: "optional",
        defaultValue: "your-api-key-here"
    };

    const MaxDataPoints = {
        ref: "prop.maxDataPoints",
        label: "Max Data Points per Object",
        type: "integer",
        defaultValue: 1000,
        min: 100,
        max: 10000
    };

    const PageSize = {
        ref: "prop.pageSize",
        label: "Page Size for Data Fetching",
        type: "integer",
        defaultValue: 500,
        min: 100,
        max: 2000
    };

    // Property panel configuration
    let appearanceSection = {
        uses: "settings",
        items: {
            objectID: DropdownSelect,
            apiKey: ApiKey,
            maxDataPoints: MaxDataPoints,
            pageSize: PageSize,
            ButtonInfo: {
                type: "items",
                label: "Role Configuration",
                items: {
                    promptBox: {
                        ref: "prop.promptBox",
                        component: "textarea",
                        label: "Data Analyst Prompt",
                        type: "string",
                        maxlength: 2000,
                        defaultValue: "You are a highly skilled data analyst. Analyze the provided JSON data and answer queries with clear insights. Focus on patterns, trends, and actionable recommendations. Respond in HTML format without code blocks.",
                    },
                    promptBox_Hr: {
                        ref: "prop.promptBox_Hr",
                        component: "textarea",
                        label: "HR Leader Prompt",
                        type: "string",
                        maxlength: 2000,
                        defaultValue: "You are an experienced HR leader specializing in talent management. Analyze employee data to provide insights on performance, engagement, and organizational development. Respond in HTML format without code blocks.",
                    },
                    promptBox_Consultant: {
                        ref: "prop.promptBox_Consultant",
                        component: "textarea",
                        label: "Business Consultant Prompt",
                        type: "string",
                        maxlength: 2000,
                        defaultValue: "You are a strategic business consultant. Analyze business data to provide insights on market trends, opportunities, and strategic recommendations. Respond in HTML format without code blocks.",
                    }
                }
            }
        }
    };

    return {
        template: template,
        definition: {
            type: "items",
            component: "accordion",
            label: "Chatbot Settings",
            items: {
                appearance: appearanceSection,
            }
        },
        support: {
            snapshot: true,
            export: true,
            exportData: false
        },

        paint: function ($element, layout) {
            const app = qlik.currApp(this);
            const currentSheetId = qlik.navigation.getCurrentSheetId();
            
            // Initialize managers
            const dataManager = new DataManager(app, {
                maxDataPoints: layout.prop.maxDataPoints || 1000,
                pageSize: layout.prop.pageSize || 500
            });
            
            const openAIClient = new OpenAIClient(layout.prop.apiKey);
            const chatManager = new ChatManager();

            // Get current sheet title
            app.getObjectProperties(currentSheetId.sheetId).then(function(model) {
                $("#welcome_msg").text(model.properties.qMetaDef.title);
            });

            // Initialize chat history state
            let chatHistory = [];
            if (chatHistory.length === 0) {
                $('#download-button').prop('disabled', true);
                $('#download-button').addClass('disabled-btn');
            }

            // Role management
            let currentRole = 'Data Analyst';
            let currentPrompt = layout.prop.promptBox;
            let answerContainerClass = 'ans_analyst';

            // Role selection handlers
            $('.role-btn').on('click', function() {
                $('.role-btn').removeClass('selected');
                $(this).addClass('selected');
                currentRole = $(this).text();

                switch (currentRole) {
                    case "Data Analyst":
                        currentPrompt = layout.prop.promptBox;
                        answerContainerClass = "ans_analyst";
                        break;
                    case "Hr Leader":
                        currentPrompt = layout.prop.promptBox_Hr;
                        answerContainerClass = "ans_hr";
                        break;
                    case "Business Consultant":
                        currentPrompt = layout.prop.promptBox_Consultant;
                        answerContainerClass = "ans_consultant";
                        break;
                }
            });

            // Initialize default role
            $(document).ready(function() {
                $('.role-container .role-btn.selected').click();
            });

            // Auto-detect sheet objects and load data
            const loadSheetData = async () => {
                try {
                    const objectIds = await dataManager.getCurrentSheetObjectIds();
                    const allData = await dataManager.fetchAllObjectsData(objectIds);
                    
                    // Store data for chat queries
                    window.sheetData = allData;
                    
                    // Update placeholder
                    const question = document.getElementById("question");
                    question.setAttribute("placeholder", `Ask questions about ${objectIds.length} objects on this sheet`);
                    
                    console.log(`Loaded data from ${objectIds.length} objects`, allData);
                    
                } catch (error) {
                    console.error("Error loading sheet data:", error);
                    const question = document.getElementById("question");
                    question.setAttribute("placeholder", "Error loading data. Please try again.");
                }
            };

            // Chat functionality
            const sendMessage = async (message) => {
                if (!message.trim()) return;

                try {
                    // Add user message to chat
                    chatManager.addMessage(message, 'user', currentRole);
                    
                    // Show typing indicator
                    chatManager.showTyping();
                    
                    // Prepare data for AI
                    const dataContext = window.sheetData || {};
                    const prompt = `${currentPrompt}\n\nData: ${JSON.stringify(dataContext)}\n\nQuery: ${message}`;
                    
                    // Get AI response
                    const response = await openAIClient.sendMessage(prompt);
                    
                    // Hide typing indicator
                    chatManager.hideTyping();
                    
                    // Add AI response to chat
                    chatManager.addMessage(response, 'ai', currentRole, answerContainerClass);
                    
                    // Update chat history
                    chatHistory.push({
                        role: currentRole,
                        question: message,
                        answer: response,
                        timestamp: new Date()
                    });
                    
                    // Enable download button
                    $('#download-button').prop('disabled', false);
                    $('#download-button').removeClass('disabled-btn');
                    
                } catch (error) {
                    console.error("Error sending message:", error);
                    chatManager.hideTyping();
                    chatManager.addMessage("Sorry, there was an error processing your request. Please try again.", 'ai', currentRole, 'error');
                }
            };

            // Event handlers
            $('#btn').on('click', async function(e) {
                e.preventDefault();
                const message = $('#question').val();
                await sendMessage(message);
                $('#question').val('');
            });

            $('#question').on('keypress', async function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    const message = $(this).val();
                    await sendMessage(message);
                    $(this).val('');
                }
            });

            // Chat window controls
            $('#openChat').on('click', function() {
                $('#myForm').show();
                // Load data when chat opens
                loadSheetData();
            });

            $('#closeChat').on('click', function() {
                $('#myForm').hide();
            });

            // Download chat history
            $('#download-button').on('click', function() {
                if (chatHistory.length === 0) return;
                
                const dataStr = JSON.stringify(chatHistory, null, 2);
                const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
                
                const exportFileDefaultName = `chat-history-${new Date().toISOString().split('T')[0]}.json`;
                
                const linkElement = document.createElement('a');
                linkElement.setAttribute('href', dataUri);
                linkElement.setAttribute('download', exportFileDefaultName);
                linkElement.click();
            });

            // Voice recognition (if supported)
            if ('webkitSpeechRecognition' in window) {
                const recognition = new webkitSpeechRecognition();
                recognition.continuous = false;
                recognition.interimResults = false;
                recognition.lang = 'en-US';

                $('#startRecognition').on('click', function() {
                    recognition.start();
                    $(this).addClass('listening');
                });

                recognition.onresult = function(event) {
                    const transcript = event.results[0][0].transcript;
                    $('#question').val(transcript);
                    $('#startRecognition').removeClass('listening');
                };

                recognition.onerror = function(event) {
                    console.error('Speech recognition error:', event.error);
                    $('#startRecognition').removeClass('listening');
                };
            }
        }
    };
});
