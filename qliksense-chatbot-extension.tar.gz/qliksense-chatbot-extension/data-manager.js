define(['qlik'], function(qlik) {
    'use strict';

    /**
     * DataManager class for efficient data fetching from QlikSense objects
     */
    class DataManager {
        constructor(app, options = {}) {
            this.app = app;
            this.maxDataPoints = options.maxDataPoints || 1000;
            this.pageSize = options.pageSize || 500;
            this.cache = new Map();
        }

        /**
         * Get all object IDs from the current sheet
         */
        async getCurrentSheetObjectIds() {
            try {
                const currentSheetId = qlik.navigation.getCurrentSheetId();
                const objectIds = [];

                return new Promise((resolve, reject) => {
                    this.app.getAppObjectList('sheet', (reply) => {
                        try {
                            const sheets = reply.qAppObjectList.qItems;
                            const currentSheet = sheets.find(sheet => 
                                sheet.qInfo.qId === currentSheetId.sheetId
                            );

                            if (currentSheet && currentSheet.qData.cells) {
                                currentSheet.qData.cells.forEach(cell => {
                                    if (cell.name && cell.name.trim()) {
                                        objectIds.push(cell.name.trim());
                                    }
                                });
                            }

                            resolve(objectIds);
                        } catch (error) {
                            reject(error);
                        }
                    });
                });
            } catch (error) {
                console.error('Error getting sheet object IDs:', error);
                throw error;
            }
        }

        /**
         * Fetch data from a single object with pagination
         */
        async fetchObjectData(objectId) {
            try {
                // Check cache first
                if (this.cache.has(objectId)) {
                    return this.cache.get(objectId);
                }

                const model = await this.app.getObject(objectId);
                const layout = model.layout;

                if (!layout.qHyperCube) {
                    console.warn(`Object ${objectId} has no hypercube`);
                    return null;
                }

                const totalDimensions = layout.qHyperCube.qDimensionInfo.length;
                const totalMeasures = layout.qHyperCube.qMeasureInfo.length;
                const totalColumns = totalDimensions + totalMeasures;
                const totalRows = layout.qHyperCube.qSize.qcy;

                // Skip if no data
                if (totalRows === 0) {
                    console.warn(`Object ${objectId} has no data`);
                    return null;
                }

                // Determine how much data to fetch
                const maxRows = Math.min(totalRows, this.maxDataPoints);
                const sampleRate = totalRows > this.maxDataPoints ? 
                    Math.floor(totalRows / this.maxDataPoints) : 1;

                // Get headers
                const dimensionHeaders = layout.qHyperCube.qDimensionInfo.map(dim => 
                    dim.qFallbackTitle || dim.qGroupFieldDefs?.[0] || `Dimension${dim.qGroupPos}`
                );
                const measureHeaders = layout.qHyperCube.qMeasureInfo.map(measure => 
                    measure.qFallbackTitle || measure.qDef?.qLabel || `Measure${measure.qSortIndex}`
                );
                const headers = [...dimensionHeaders, ...measureHeaders];

                // Fetch data in pages
                const jsonDataArray = [];
                let currentPage = 0;
                let fetchedRows = 0;

                while (fetchedRows < maxRows && currentPage * this.pageSize < totalRows) {
                    const qTop = currentPage * this.pageSize;
                    const qHeight = Math.min(this.pageSize, totalRows - qTop, maxRows - fetchedRows);

                    try {
                        const data = await model.getHyperCubeData('/qHyperCubeDef', [{
                            qTop: qTop,
                            qLeft: 0,
                            qWidth: totalColumns,
                            qHeight: qHeight,
                        }]);

                        if (data && data[0] && data[0].qMatrix) {
                            data[0].qMatrix.forEach((row, index) => {
                                // Apply sampling if needed
                                if (sampleRate === 1 || (qTop + index) % sampleRate === 0) {
                                    const jsonData = {};
                                    headers.forEach((header, colIndex) => {
                                        const cellValue = row[colIndex];
                                        jsonData[header] = cellValue?.qText || cellValue?.qNum || null;
                                    });
                                    jsonDataArray.push(jsonData);
                                    fetchedRows++;
                                }
                            });
                        }
                    } catch (pageError) {
                        console.error(`Error fetching page ${currentPage} for object ${objectId}:`, pageError);
                        break;
                    }

                    currentPage++;
                }

                const result = {
                    objectId: objectId,
                    title: layout.qInfo?.qId || objectId,
                    totalRows: totalRows,
                    fetchedRows: fetchedRows,
                    sampleRate: sampleRate,
                    headers: headers,
                    data: jsonDataArray
                };

                // Cache the result
                this.cache.set(objectId, result);

                return result;
            } catch (error) {
                console.error(`Error fetching data for object ${objectId}:`, error);
                return null;
            }
        }

        /**
         * Fetch data from all objects with error handling
         */
        async fetchAllObjectsData(objectIds) {
            const results = {};
            const errors = [];

            // Process objects in batches to avoid overwhelming the system
            const batchSize = 3;
            for (let i = 0; i < objectIds.length; i += batchSize) {
                const batch = objectIds.slice(i, i + batchSize);
                
                const batchPromises = batch.map(async (objectId) => {
                    try {
                        const data = await this.fetchObjectData(objectId);
                        if (data) {
                            results[objectId] = data;
                        }
                    } catch (error) {
                        errors.push({ objectId, error: error.message });
                        console.error(`Failed to fetch data for object ${objectId}:`, error);
                    }
                });

                await Promise.all(batchPromises);
                
                // Small delay between batches to prevent overwhelming the system
                if (i + batchSize < objectIds.length) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
            }

            if (errors.length > 0) {
                console.warn('Some objects failed to load:', errors);
            }

            return results;
        }

        /**
         * Clear the cache
         */
        clearCache() {
            this.cache.clear();
        }

        /**
         * Get cache statistics
         */
        getCacheStats() {
            return {
                size: this.cache.size,
                keys: Array.from(this.cache.keys())
            };
        }
    }

    return DataManager;
});
