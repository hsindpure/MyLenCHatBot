define([], function() {
    'use strict';

    /**
     * OpenAI Client for handling AI interactions
     */
    class OpenAIClient {
        constructor(apiKey) {
            this.apiKey = apiKey;
            this.baseUrl = 'https://api.openai.com/v1/chat/completions';
            this.model = 'gpt-4o'; // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        }

        /**
         * Send a message to OpenAI and get response
         */
        async sendMessage(prompt, options = {}) {
            try {
                const response = await fetch(this.baseUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${this.apiKey}`
                    },
                    body: JSON.stringify({
                        model: this.model,
                        messages: [
                            {
                                role: 'system',
                                content: 'You are a helpful assistant that analyzes data and provides insights. Always respond in HTML format without code blocks or markdown. Structure your response with appropriate HTML tags for readability.'
                            },
                            {
                                role: 'user',
                                content: prompt
                            }
                        ],
                        max_tokens: options.maxTokens || 2000,
                        temperature: options.temperature || 0.7,
                        top_p: options.topP || 1,
                        frequency_penalty: options.frequencyPenalty || 0,
                        presence_penalty: options.presencePenalty || 0
                    })
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(`OpenAI API error: ${errorData.error?.message || response.statusText}`);
                }

                const data = await response.json();
                
                if (!data.choices || !data.choices[0] || !data.choices[0].message) {
                    throw new Error('Invalid response format from OpenAI API');
                }

                return data.choices[0].message.content;
            } catch (error) {
                console.error('Error calling OpenAI API:', error);
                
                // Return user-friendly error messages
                if (error.message.includes('401')) {
                    throw new Error('Invalid API key. Please check your OpenAI API key.');
                } else if (error.message.includes('429')) {
                    throw new Error('Rate limit exceeded. Please try again later.');
                } else if (error.message.includes('500')) {
                    throw new Error('OpenAI service is temporarily unavailable. Please try again later.');
                } else {
                    throw new Error(`AI service error: ${error.message}`);
                }
            }
        }

        /**
         * Check if the API key is valid
         */
        async validateApiKey() {
            try {
                const response = await this.sendMessage('Hello', { maxTokens: 10 });
                return true;
            } catch (error) {
                return false;
            }
        }
    }

    return OpenAIClient;
});
